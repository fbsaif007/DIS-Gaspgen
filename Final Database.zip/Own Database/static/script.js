/*Navigation Links*/
var navLinks = document.getElementById("navLinks");

function showMenu() {
  navLinks.style.right = "0";
}

function hideMenu() {
  navLinks.style.right = "-200px";
}
/*Login and signup page*/
const formOpenBtn = document.querySelector("#form-open"),
  home = document.querySelector(".home"),
  formContainer = document.querySelector(".form_container"),
  formCloseBtn = document.querySelector(".form_close"),
  signupBtn = document.querySelector("#signup"),
  loginBtn = document.querySelector("#login"),
  pwShowHide = document.querySelectorAll(".pw_hide");

formOpenBtn.addEventListener("click", () => home.classList.add("show"));
formCloseBtn.addEventListener("click", () => home.classList.remove("show"));

pwShowHide.forEach((icon) => {
  icon.addEventListener("click", () => {
    let getPwInput = icon.parentElement.querySelector("input");
    if (getPwInput.type === "password") {
      getPwInput.type = "text";
      icon.classList.replace("uil-eye-slash", "uil-eye");
    } else {
      getPwInput.type = "password";
      icon.classList.replace("uil-eye", "uil-eye-slash");
    }
  });
});

signupBtn.addEventListener("click", (e) => {
  e.preventDefault();
  formContainer.classList.add("active");
});
loginBtn.addEventListener("click", (e) => {
  e.preventDefault();
  formContainer.classList.remove("active");
});
/*Bar Chart*/
var ctx = document.getElementById("myChart").getContext("2d");
var myChart = new Chart(ctx, {
  type: "bar",
  data: {
    labels: [
      "Coursera",
      "Udemy",
      "Khan Academy",
      "edX",
      "CodeAcademy",
      "Dulingio",
      "TED-Ed",
      "SkillShare",
      "FutureLearn",
      "LinkedIn Learning",
    ],
    datasets: [
      {
        label: "Visits",
        data: [15264, 14876, 19864, 10976, 8293, 7864, 5968, 4982, 4593, 9275],
        backgroundColor: [
          "#ffa500",
          "#66c2a5",
          "#8da0cb",
          "#e78ac3",
          "#a6d854",
          "#ffd92f",
          "#868686",
          "#177617",
          "#9a9a05",
          "#b6dfd4",
        ],
        borderColor: "#fff",
        borderWidth: 1,
      },
    ],
  },
  options: {
    legend: {
      display: true,
      position: "bottom",
      labels: {
        fontColor: "#333",
        fontFamily: "Arial",
        fontSize: 12,
        boxWidth: 12,
        padding: 10,
      },
    },
    scales: {
      yAxes: [
        {
          ticks: {
            beginAtZero: true,
            fontColor: "#333",
            fontFamily: "Arial",
            fontSize: 12,
          },
          gridLines: {
            color: "#ccc",
          },
        },
      ],
      xAxes: [
        {
          ticks: {
            fontColor: "#333",
            fontFamily: "Arial",
            fontSize: 12,
          },
          gridLines: {
            display: false,
          },
        },
      ],
    },
  },
});
